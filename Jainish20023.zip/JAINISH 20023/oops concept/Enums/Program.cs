﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enums
{
    enum Month 
    {
        JAN=1,
		FEB,
		MAR,
		APR=20,
		MAY,
		JUNE,
		JULY,
		AUG,
		SEPT,
		OCT,
		NOV,
		DEC,
            
    }
    class Program
    {
        public void DemoExceptional()
        {
            try
            {
                int a = 100;
                Console.WriteLine("Value of a is:"+a);
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
            finally
            {
                Console.WriteLine("Finally");
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Convert.ToInt32(Month.MAY) + 11);

            Console.ReadKey();
        }
    }
}
